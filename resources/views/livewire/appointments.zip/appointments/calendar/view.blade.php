<div id="fullcalendar" class="calendar-wrapper"></div>

<script>
    (function initFC() {
        const el = document.getElementById('fullcalendar');
        if (!el || typeof FullCalendar === 'undefined') {
            setTimeout(initFC, 100);
            return;
        }

        const events = @json($calendarEvents);

        if (window._calendarInstance) {
            window._calendarInstance.destroy();
        }

        window._calendarInstance = new FullCalendar.Calendar(el, {
            initialView: 'dayGridMonth',
            locale: 'es',
            headerToolbar: false,
            events: events,
            height: 'auto',
            eventClick: (info) => {
                const wireEl = el.closest('[wire\\:id]');
                if (wireEl) {
                    Livewire.find(wireEl.getAttribute('wire:id'))
                        .call('viewAppointment', info.event.id);
                }
            },
            eventContent: (arg) => ({
                html: '<div class="fc-event-inner">' + arg.event.title + '</div>'
            }),
        });

        window._calendarInstance.render();

        window.addEventListener('calendar-events-updated', (e) => {
            if (!window._calendarInstance) return;
            window._calendarInstance.removeAllEvents();
            window._calendarInstance.addEventSource(e.detail.events);
        });
    })();
</script>
