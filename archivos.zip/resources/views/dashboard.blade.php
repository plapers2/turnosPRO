<x-app-layout>
    {{-- Material Symbols Rounded --}}
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

    <style>
        .material-symbols-rounded {
            font-variation-settings: 'FILL' 1, 'wght' 400, 'GRAD' 0, 'opsz' 24;
            user-select: none;
            line-height: 1;
            vertical-align: middle;
        }

        .ms-outline {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
        }

        .btn-toggle {
            padding: 6px 14px;
            border-radius: 9999px;
            font-size: 13px;
            font-weight: 600;
            color: #524438;
            transition: all .2s ease;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .btn-toggle:hover {
            background: #ebe8e2;
        }

        .btn-active {
            background: #663a00;
            color: white;
            box-shadow: 0 2px 8px rgba(0, 0, 0, .08);
        }

        .kpi-card {
            background: var(--md-sys-color-surface-container-lowest, #fff);
            border-radius: 16px;
            padding: 20px;
            border: 1px solid rgba(0, 0, 0, .06);
            display: flex;
            flex-direction: column;
            gap: 4px;
            transition: box-shadow .2s;
        }

        .kpi-card:hover {
            box-shadow: 0 4px 16px rgba(0, 0, 0, .07);
        }

        .kpi-icon {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 8px;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            font-size: 11px;
            font-weight: 600;
            padding: 3px 10px;
            border-radius: 999px;
        }

        .fade-in {
            animation: fade .25s ease;
        }

        @keyframes fade {
            from {
                opacity: 0;
                transform: translateY(4px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>

    <main class="flex-1 bg-surface px-6 py-8">
        <div class="max-w-7xl mx-auto flex flex-col gap-8">

            {{-- HEADER --}}
            <header class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
                <div>
                    <h1 class="text-3xl font-bold text-on-surface">
                        Buenos días, {{ auth()->user()->name }}
                    </h1>
                    <p class="text-sm text-on-surface-variant mt-1 flex items-center gap-1.5">
                        <span class="material-symbols-rounded ms-outline text-on-surface-variant"
                            style="font-size:1rem;">calendar_today</span>
                        {{ now()->locale('es')->isoFormat('dddd, D [de] MMMM [de] YYYY') }}
                    </p>
                </div>

                {{-- TOGGLE PERÍODO --}}
                <div class="flex gap-1 bg-surface-container rounded-full p-1 border border-outline-variant/40">
                    <button data-period="hoy" class="period-btn btn-toggle">
                        <span class="material-symbols-rounded ms-outline" style="font-size:.95rem;">today</span>
                        Hoy
                    </button>
                    <button data-period="semana" class="period-btn btn-toggle">
                        <span class="material-symbols-rounded ms-outline" style="font-size:.95rem;">date_range</span>
                        Semana
                    </button>
                    <button data-period="mes" class="period-btn btn-toggle">
                        <span class="material-symbols-rounded ms-outline"
                            style="font-size:.95rem;">calendar_month</span>
                        Mes
                    </button>
                </div>
            </header>

            {{-- KPIs --}}
            <section id="kpi-grid" class="grid grid-cols-2 sm:grid-cols-4 gap-3"></section>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

                {{-- LEFT --}}
                <div class="lg:col-span-2 flex flex-col gap-6">

                    {{-- CHART --}}
                    <div class="bg-surface-container-lowest rounded-2xl p-6 border border-outline-variant/20 shadow-sm">
                        <div class="flex justify-between items-center mb-5">
                            <h2 class="font-semibold text-primary flex items-center gap-2">
                                <span class="material-symbols-rounded ms-outline"
                                    style="font-size:1.15rem;">bar_chart</span>
                                Ocupación
                            </h2>
                            <div
                                class="flex gap-1 bg-surface-container rounded-full p-1 border border-outline-variant/40">
                                <button data-chart="barras" class="chart-btn btn-toggle">
                                    <span class="material-symbols-rounded ms-outline"
                                        style="font-size:.9rem;">bar_chart</span>
                                    Barras
                                </button>
                                <button data-chart="lineas" class="chart-btn btn-toggle">
                                    <span class="material-symbols-rounded ms-outline"
                                        style="font-size:.9rem;">show_chart</span>
                                    Líneas
                                </button>
                            </div>
                        </div>
                        <div class="h-64">
                            <canvas id="mainChart"></canvas>
                        </div>
                    </div>

                    {{-- APPOINTMENTS --}}
                    <div class="bg-surface-container-lowest rounded-2xl p-6 border border-outline-variant/20 shadow-sm">
                        <h2 class="font-semibold text-primary mb-4 flex items-center gap-2">
                            <span class="material-symbols-rounded ms-outline" style="font-size:1.15rem;">upcoming</span>
                            Próximas citas
                        </h2>
                        <div id="appts-list" class="flex flex-col gap-3"></div>
                    </div>

                </div>

                {{-- RIGHT --}}
                <div class="flex flex-col gap-6">

                    {{-- SERVICES --}}
                    <div class="bg-surface-container-lowest rounded-2xl p-6 border border-outline-variant/20 shadow-sm">
                        <h2 class="font-semibold text-primary mb-4 flex items-center gap-2">
                            <span class="material-symbols-rounded ms-outline" style="font-size:1.15rem;">star</span>
                            Servicios más solicitados
                        </h2>
                        <div id="services-list" class="flex flex-col gap-3"></div>
                    </div>

                    {{-- ATTENDANCE --}}
                    <div class="bg-primary-container/10 rounded-2xl p-6 border border-primary/10 space-y-3">
                        <p class="text-xs uppercase tracking-widest text-primary flex items-center gap-1.5">
                            <span class="material-symbols-rounded" style="font-size:1rem;">monitoring</span>
                            Tasa de asistencia
                        </p>
                        <div id="asistencia-value" class="text-5xl font-extrabold text-primary"></div>
                        <p id="asistencia-sub" class="text-sm text-on-surface-variant"></p>
                        <div class="h-1.5 bg-black/10 rounded-full overflow-hidden">
                            <div id="asistencia-bar" class="h-full bg-primary transition-all duration-500"></div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </main>

    @push('scripts')
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js"></script>

        <script>
            const DATA = @json($kpis);
            const APPTS = @json($appointments);
            const SERVICES = @json($services);

            // Configuración de cada KPI card: icono, colores bg/icon
            const KPI_META = [{
                    icon: 'calendar_month',
                    bg: '#f0f4ff',
                    color: '#3b5bdb'
                }, // Total
                {
                    icon: 'task_alt',
                    bg: '#f0fdf4',
                    color: '#16a34a'
                }, // Confirmadas
                {
                    icon: 'event_busy',
                    bg: '#fff1f2',
                    color: '#dc2626'
                }, // Canceladas
                {
                    icon: 'hourglass_empty',
                    bg: '#fffbeb',
                    color: '#d97706'
                }, // Pendientes
            ];

            let currentPeriod = localStorage.getItem('dashboard_period') || 'hoy';
            let currentChart = localStorage.getItem('dashboard_chart') || 'barras';
            let chartInstance = null;

            function setActive(selector, value, attr) {
                document.querySelectorAll(selector).forEach(btn => {
                    btn.classList.toggle('btn-active', btn.dataset[attr] === value);
                });
            }

            function renderKPIs(period) {
                document.getElementById('kpi-grid').innerHTML =
                    DATA[period].kpis.map((k, i) => {
                        const m = KPI_META[i] || {
                            icon: 'info',
                            bg: '#f5f5f5',
                            color: '#555'
                        };
                        return `
                        <div class="kpi-card fade-in">
                            <div class="kpi-icon" style="background:${m.bg}">
                                <span class="material-symbols-rounded" style="font-size:1.25rem;color:${m.color}">${m.icon}</span>
                            </div>
                            <span class="text-xs text-on-surface-variant">${k.label}</span>
                            <span class="text-3xl font-bold text-on-surface">${k.value}</span>
                        </div>`;
                    }).join('');
            }

            function renderChart(period, type) {
                if (chartInstance) chartInstance.destroy();

                const isLine = type === 'lineas';
                const colors = {
                    primary: '#663a00',
                    soft: '#ffb870',
                    success: '#046289',
                    error: '#ba1a1a'
                };

                let data = JSON.parse(JSON.stringify(DATA[period][type]));

                data.datasets = data.datasets.map((ds, i) => {
                    if (!isLine) {
                        return {
                            ...ds,
                            backgroundColor: colors.soft,
                            borderRadius: 8
                        };
                    }
                    return {
                        ...ds,
                        borderColor: i === 0 ? colors.success : colors.error,
                        tension: 0.4,
                        pointRadius: 3
                    };
                });

                chartInstance = new Chart(document.getElementById('mainChart'), {
                    type: isLine ? 'line' : 'bar',
                    data,
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                display: false
                            }
                        },
                        scales: {
                            x: {
                                grid: {
                                    display: false
                                }
                            },
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            }

            // Badges de estado con icono
            const STATUS_CONFIG = {
                confirmed: {
                    label: 'Confirmada',
                    icon: 'check_circle',
                    bg: '#f0fdf4',
                    color: '#16a34a'
                },
                pending: {
                    label: 'Pendiente',
                    icon: 'hourglass_empty',
                    bg: '#fffbeb',
                    color: '#d97706'
                },
                completed: {
                    label: 'Completada',
                    icon: 'verified',
                    bg: '#eff6ff',
                    color: '#2563eb'
                },
                cancelled: {
                    label: 'Cancelada',
                    icon: 'cancel',
                    bg: '#fff1f2',
                    color: '#dc2626'
                },
            };

            function statusBadge(status, label) {
                const cfg = STATUS_CONFIG[status] || {
                    label,
                    icon: 'info',
                    bg: '#f5f5f5',
                    color: '#555'
                };
                return `<span class="status-badge" style="background:${cfg.bg};color:${cfg.color}">
                            <span class="material-symbols-rounded" style="font-size:.85rem">${cfg.icon}</span>
                            ${cfg.label}
                        </span>`;
            }

            function renderAppts() {
                if (!APPTS || !APPTS.length) {
                    document.getElementById('appts-list').innerHTML =
                        `<p class="text-sm text-on-surface-variant flex items-center gap-2">
                            <span class="material-symbols-rounded ms-outline" style="font-size:1.1rem">event_busy</span>
                            No hay citas en las próximas 2 horas.
                         </p>`;
                    return;
                }

                document.getElementById('appts-list').innerHTML =
                    APPTS.map(a => `
                        <div class="flex items-center justify-between p-4 rounded-xl bg-surface-container-low fade-in">
                            <div class="flex items-start gap-3">
                                <span class="material-symbols-rounded text-primary ms-outline mt-0.5" style="font-size:1.1rem">schedule</span>
                                <div>
                                    <p class="text-sm font-semibold text-on-surface">
                                        <span class="text-primary">${a.time}</span>
                                        &nbsp;·&nbsp;${a.name}
                                    </p>
                                    <p class="text-xs text-on-surface-variant mt-0.5">
                                        ${a.service}${a.staff !== 'Sin asignar' ? ' &mdash; ' + a.staff : ''}
                                    </p>
                                </div>
                            </div>
                            ${statusBadge(a.status, a.label)}
                        </div>
                    `).join('');
            }

            function renderServices(period) {
                if (!SERVICES || !SERVICES[period]) return;

                document.getElementById('services-list').innerHTML =
                    SERVICES[period].map(([name, count]) => `
                        <div class="flex items-center justify-between fade-in">
                            <div class="flex items-center gap-2">
                                <span class="material-symbols-rounded text-on-surface-variant ms-outline" style="font-size:1rem">auto_fix_normal</span>
                                <span class="text-sm text-on-surface">${name}</span>
                            </div>
                            <span class="text-xs font-semibold bg-primary/10 text-primary px-2 py-0.5 rounded-full">${count}x</span>
                        </div>
                    `).join('');
            }

            function renderAsistencia(period) {
                const a = DATA[period].asistencia;
                document.getElementById('asistencia-value').textContent = a.pct + '%';
                document.getElementById('asistencia-sub').textContent = a.text;
                document.getElementById('asistencia-bar').style.width = a.pct + '%';
            }

            function updateDashboard() {
                setActive('.period-btn', currentPeriod, 'period');
                setActive('.chart-btn', currentChart, 'chart');

                renderKPIs(currentPeriod);
                renderChart(currentPeriod, currentChart);
                renderAppts();
                renderAsistencia(currentPeriod);

                if (SERVICES) renderServices(currentPeriod);
            }

            // EVENTS
            document.querySelectorAll('.period-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    currentPeriod = btn.dataset.period;
                    localStorage.setItem('dashboard_period', currentPeriod);
                    updateDashboard();
                });
            });

            document.querySelectorAll('.chart-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    currentChart = btn.dataset.chart;
                    localStorage.setItem('dashboard_chart', currentChart);
                    renderChart(currentPeriod, currentChart);
                    setActive('.chart-btn', currentChart, 'chart');
                });
            });

            updateDashboard();
        </script>
    @endpush
</x-app-layout>
