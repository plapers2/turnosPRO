<x-app-layout>
    <main class="flex-1 flex flex-col h-full overflow-y-auto bg-surface">

        <!-- HEADER -->
        <x-form.header icono="arrow_back" titulo="Editar Usuario" ruta="users" subtitulo="Gestion de Profesionales" />

        <!-- FORM -->
        <div class="px-8 pb-20">
            <form action="{{ route('users.update', $user->id) }}" method="POST" enctype="multipart/form-data"
                class="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-10">
                @csrf
                @method('PUT')
                @include('users.form')
            </form>
        </div>

    </main>
</x-app-layout>
